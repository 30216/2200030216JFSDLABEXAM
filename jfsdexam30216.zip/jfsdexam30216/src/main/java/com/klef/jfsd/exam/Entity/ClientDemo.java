package com.klef.jfsd.exam.Entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ClientDemo {
    public static void main(String[] args) {
        // Configure and build SessionFactory
        Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
        SessionFactory factory = cfg.buildSessionFactory();

        // Open session and begin transaction
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();

        // Create instances of Car and Truck
        Car car = new Car();
        car.setName("Tesla Model S");
        car.setType("Electric");
        car.setMaxSpeed(200);
        car.setColor("Red");
        car.setNumberOfDoors(4);

        Truck truck = new Truck();
        truck.setName("Ford F-150");
        truck.setType("Pickup");
        truck.setMaxSpeed(120);
        truck.setColor("Blue");
        truck.setLoadCapacity(5000);

        // Save objects to database
        session.save(car);
        session.save(truck);

        // Commit transaction and close session
        tx.commit();
        session.close();

        System.out.println("Records inserted successfully!");
    }
}

